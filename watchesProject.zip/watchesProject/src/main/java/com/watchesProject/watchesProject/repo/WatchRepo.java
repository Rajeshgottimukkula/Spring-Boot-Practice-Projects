package com.watchesProject.watchesProject.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.watchesProject.watchesProject.Entity.Watches;

public interface WatchRepo extends JpaRepository<Watches,Integer> {

	Watches findByName(String name);

}
