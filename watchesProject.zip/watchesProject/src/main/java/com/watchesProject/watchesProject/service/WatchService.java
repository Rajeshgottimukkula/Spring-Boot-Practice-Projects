package com.watchesProject.watchesProject.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.watchesProject.watchesProject.Entity.Watches;
import com.watchesProject.watchesProject.repo.WatchRepo;

@Service
public class WatchService {

	@Autowired
	WatchRepo repo;
	
	public Watches insertIntoDb(Watches wt) {
		// TODO Auto-generated method stub
		return repo.save(wt);
	}

	public List<Watches> fetchWatches() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	public Watches fetchByName(String name) {
		// TODO Auto-generated method stub
		return repo.findByName(name);
	}

	public Watches updateById(int id, Watches newData) {
		// TODO Auto-generated method stub
		Watches extData=repo.findById(id).get();
		if(Objects.nonNull(newData)) {
			extData.setName(newData.getName());
			extData.setPrice(newData.getPrice());
			extData.setRating(newData.getRating());
		}
		return repo.save(extData);
		
	}

	public String deleteById(int id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
		return "Deleted";
	}

}
