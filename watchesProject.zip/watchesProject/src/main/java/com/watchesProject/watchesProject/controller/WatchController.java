package com.watchesProject.watchesProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.watchesProject.watchesProject.Entity.Watches;
import com.watchesProject.watchesProject.service.WatchService;

@RestController
public class WatchController {

	@Autowired
	WatchService ws;
	
	
	@PostMapping("/Watches")
	public Watches insertIntoDb(@RequestBody Watches wt) {
		
		return ws.insertIntoDb(wt);
		
	}
	
	@GetMapping("/Watches")
	public List<Watches> fetchWatches(){
		return ws.fetchWatches();
	}
	
	@GetMapping("/Watches/{name}")
	public Watches fetchByName(@PathVariable("name") String name) {
		return ws.fetchByName(name);
	}
	
	@PutMapping("Watches/{id}")
	public Watches updateById(@PathVariable int id,@RequestBody Watches newData
			) {
		return ws.updateById(id,newData);
	}
	
	
	@DeleteMapping("/Watches/{id}")
	public String deleteById(@PathVariable int id) {
		return ws.deleteById(id);
	}
	
	
}
