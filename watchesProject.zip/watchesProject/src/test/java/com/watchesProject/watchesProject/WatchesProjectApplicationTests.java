package com.watchesProject.watchesProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WatchesProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
